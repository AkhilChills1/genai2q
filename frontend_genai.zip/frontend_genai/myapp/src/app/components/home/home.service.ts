import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { url } from 'inspector';
 
@Injectable({
  providedIn: 'root'
})
  export class HomeService {
 
    constructor(private http: HttpClient) { }
 
    LoadData(url:string) {
      return this.http.get(url)
    }

    getUsers(url:any) {
      return this.http.get(url);
    }
   
    postUsers(url:any, user:any) {
      return this.http.post(url, user);
    }
 
 
  }