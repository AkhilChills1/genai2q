import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
dataOne:any=[];
dataTwo:any=[];
urlOne:string = "https://jsonplaceholder.typicode.com/users";
urlTwo:string = 'https://jsonplaceholder.typicode.com/users';
  constructor(private homeservice:HomeService) { }

  ngOnInit(): void {
    this.getDataServer();
    this.getData();
  }
  
  getDataServer() {
    let obj = this.homeservice.LoadData(this.urlOne);
    obj.subscribe(data => {this.dataOne = data;
    console.log(this.dataOne);
    })
  };
  getData() {
    this.homeservice
      .getUsers(this.urlTwo)
      .subscribe((data: any) => {
        this.dataTwo = data;
        console.log(this.dataTwo);
      });
  }
 
  addUser() {
    let sampleData = {id: "", name: "Manikandan", username: "Manikandan", email: "Mani@test.com",phone: "987654321",website: "aig.com"};
    this.homeservice.postUsers(this.urlTwo,sampleData)
      .subscribe(myData => this.dataTwo.push(myData));
  }

}
